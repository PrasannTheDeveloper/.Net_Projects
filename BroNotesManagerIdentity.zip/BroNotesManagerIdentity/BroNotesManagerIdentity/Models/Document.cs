﻿namespace BroNotesManagerIdentity.Models
{
        public class Document
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public string Type { get; set; }
        }
    }

