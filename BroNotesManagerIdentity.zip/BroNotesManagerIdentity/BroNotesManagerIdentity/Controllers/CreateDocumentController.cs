﻿using Octokit;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using BroNotesManagerIdentity.Models;
using Microsoft.AspNetCore.Authorization;

namespace BroNotesManagerIdentity.Controllers
{
    [Authorize]
    public class CreateDocumentController : Controller
    {

        private readonly string _apiKey = "";
        private readonly string _owner = "PrasannTheDeveloper";
        private readonly string _repository = "publicRepo";

        public async Task<IActionResult> Index(string path = "")
        {
            var documents = await GetDocumentsFromGitHub(path);
            ViewBag.CurrentFolder = path;
            return View(documents);
        }

        private async Task<List<Document>> GetDocumentsFromGitHub(string folderPath = "")
        {
            var documents = new List<Document>();
            var apiUrl = $"https://api.github.com/repos/{_owner}/{_repository}/contents/{folderPath}";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("AppName", "1.0"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

                var response = await client.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var files = JsonConvert.DeserializeObject<List<GitHubFile>>(content);

                foreach (var file in files)
                {
                    documents.Add(new Document
                    {
                        Name = file.Name,
                        Path = file.Path,
                        Type = file.Type == "file" ? Path.GetExtension(file.Name).TrimStart('.') : "folder"
                    });
                }
            }

            return documents;
        }
        private async Task<bool> CreateFolderInGitHub(string folderPath)
        {
            // Ensure folderPath is properly formatted
            folderPath = folderPath.Trim('/');

            string apiUrl = $"https://api.github.com/repos/{_owner}/{_repository}/contents/{folderPath}/placeholder.txt";

            var content = new
            {
                message = $"Create folder {folderPath} with placeholder",
                content = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("This is a placeholder file to keep the folder.")),
                branch = "main"
            };

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("AppName", "1.0"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

                var jsonContent = new StringContent(JsonConvert.SerializeObject(content), System.Text.Encoding.UTF8, "application/json");
                var response = await client.PutAsync(apiUrl, jsonContent);

                return response.IsSuccessStatusCode;
            }
        }

        public async Task<IActionResult> CreateFolder(string folderName, string parentPath = "")
        {
            if (string.IsNullOrWhiteSpace(folderName))
                return BadRequest("Folder name cannot be empty");

            // Create full folder path (nested folder)
            string folderPath = string.IsNullOrEmpty(parentPath) ? folderName : $"{parentPath}/{folderName}";

            bool isCreated = await CreateFolderInGitHub(folderPath);
            if (isCreated)
                return RedirectToAction("Index", new { path = parentPath });

            return StatusCode(500, "Failed to create folder");
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file, string folderPath = "")
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file selected.");

            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                var fileBytes = memoryStream.ToArray();
                string base64File = Convert.ToBase64String(fileBytes);
                string fileName = file.FileName;

                string filePath = string.IsNullOrEmpty(folderPath) ? fileName : $"{folderPath}/{fileName}";

                var apiUrl = $"https://api.github.com/repos/{_owner}/{_repository}/contents/{filePath}";

                var content = new
                {
                    message = $"Upload file {fileName}",
                    content = base64File,
                    branch = "main"
                };

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("AppName", "1.0"));
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

                    var jsonContent = new StringContent(JsonConvert.SerializeObject(content), System.Text.Encoding.UTF8, "application/json");
                    var response = await client.PutAsync(apiUrl, jsonContent);

                    if (response.IsSuccessStatusCode)
                        return RedirectToAction("Index", new { path = folderPath });

                    return StatusCode(500, "Failed to upload file.");
                }
            }
        }


        private class GitHubFile
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public string Type { get; set; }
        }
    }
}