﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using BroNotesManagerIdentity.Models;
using Microsoft.AspNetCore.Authorization;

namespace BroNotesManagerIdentity.Controllers
{
    [Authorize]
    public class DocumentController : Controller
    {
        private readonly string _apiKey = "";
        private readonly string _owner = "PrasannTheDeveloper";
        private readonly string _repository = "publicRepo";

        public async Task<ActionResult> Index(string folderPath = "")
        {
            var documents = await GetDocumentsFromGitHub(folderPath);
            ViewBag.CurrentFolder = folderPath;
            return View(documents);
        }

        public async Task<ActionResult> ViewDocument(string path, string type)
        {
            var documents = await GetDocumentsFromGitHub(Path.GetDirectoryName(path));

            var imageUrls = documents
                .Where(doc => doc.Type == "image")
                .Select(doc => $"https://raw.githubusercontent.com/{_owner}/{_repository}/main/{doc.Path}")
                .ToList();

            ViewBag.ImageUrls = imageUrls;

            if (type == "pdf")
            {
                var pdfUrl = $"https://raw.githubusercontent.com/{_owner}/{_repository}/main/{path}";
                return Redirect(pdfUrl);
            }
            else if (type == "image")
            {
                var imageUrl = $"https://raw.githubusercontent.com/{_owner}/{_repository}/main/{path}";
                ViewBag.ImageUrl = imageUrl;
                return View("ImageView");
            }

            return RedirectToAction("Index");
        }

        public async Task<ActionResult> DownloadDocument(string path)
        {
            var documentUrl = $"https://raw.githubusercontent.com/{_owner}/{_repository}/main/{path}";
            var documentName = Path.GetFileName(path);

            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(documentUrl);
                response.EnsureSuccessStatusCode();
                var stream = await response.Content.ReadAsStreamAsync();
                return File(stream, "application/octet-stream", documentName);
            }
        }

        private async Task<List<Document>> GetDocumentsFromGitHub(string folderPath = "")
        {
            var documents = new List<Document>();
            var apiUrl = $"https://api.github.com/repos/{_owner}/{_repository}/contents/{folderPath}";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("AppName", "1.0"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

                var response = await client.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();
                var content = await response.Content.ReadAsStringAsync();
                var files = JsonConvert.DeserializeObject<List<GitHubFile>>(content);

                foreach (var file in files)
                {
                    documents.Add(new Document
                    {
                        Name = file.Name,
                        Path = file.Path,
                        Type = file.Type == "file" ? Path.GetExtension(file.Name).TrimStart('.') : "folder"
                    });
                }
            }

            return documents;
        }
        public async Task<ActionResult> OpenContent(string path)
        {
            var fileUrl = $"https://raw.githubusercontent.com/{_owner}/{_repository}/main/{path}";
            return Redirect(fileUrl);
        }


        private class GitHubFile
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public string Type { get; set; }
        }
    }
}
