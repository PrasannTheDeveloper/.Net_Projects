﻿// scripts.js
document.addEventListener("DOMContentLoaded", function () {
    // Initialize Particle.js
    particlesJS.load('particles-js', 'particles.json', function () {
        console.log('Particles.js loaded!');
    });

    // GSAP Animations for Intro Page
    gsap.from(".animated-title", { opacity: 0, y: -50, duration: 1.5, ease: "power2.out" });
    gsap.from(".animated-subtitle", { opacity: 0, y: 50, duration: 1.5, delay: 0.5, ease: "power2.out" });
    gsap.from(".section-title", { opacity: 0, x: -50, duration: 1, delay: 1, ease: "power2.out" });
    gsap.from(".section-text", { opacity: 0, x: 50, duration: 1, delay: 1.5, ease: "power2.out" });
    gsap.from(".features-list", { opacity: 0, y: 20, duration: 1, delay: 2, ease: "power2.out" });
    gsap.from(".start-button", { opacity: 0, y: 20, duration: 1, delay: 2.5, ease: "power2.out" });

    // Floating Icons Animation
    gsap.to(".floating-icon", {
        y: 20,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        duration: 3,
        stagger: 0.5,
    });
});