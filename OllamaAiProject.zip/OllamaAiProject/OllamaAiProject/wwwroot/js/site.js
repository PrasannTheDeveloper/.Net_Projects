﻿//// scripts.js
//document.addEventListener("DOMContentLoaded", function () {
//    // GSAP Animations
//    gsap.from(".chat-container", { opacity: 0, y: 50, duration: 1, ease: "power2.out" });
//    gsap.from(".chat-window", { opacity: 0, x: -50, duration: 1, delay: 0.5, ease: "power2.out" });
//    gsap.from(".chat-input-form", { opacity: 0, y: 50, duration: 1, delay: 1, ease: "power2.out" });

//    // Add smooth scrolling to chat window
//    const chatWindow = document.querySelector(".chat-window");
//    chatWindow.scrollTop = chatWindow.scrollHeight;

//    // Add message animation
//    const messages = document.querySelectorAll(".message");
//    messages.forEach((message, index) => {
//        gsap.from(message, { opacity: 0, x: index % 2 === 0 ? -50 : 50, duration: 0.5, delay: index * 0.2 });
//    });
//});

// scripts.js
document.addEventListener("DOMContentLoaded", function () {
    // Initialize Particle.js
    particlesJS.load('particles-js', 'particles.json', function () {
        console.log('Particles.js loaded!');
    });

    // GSAP Animations
    gsap.from(".settings-column", { opacity: 0, x: -50, duration: 1, ease: "power2.out" });
    gsap.from(".chat-column", { opacity: 0, x: 50, duration: 1, delay: 0.5, ease: "power2.out" });

    // Floating Icons Animation
    gsap.to(".floating-icon", {
        y: 20,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        duration: 3,
        stagger: 0.5,
    });

    // Smooth scrolling for chat window
    const chatWindow = document.querySelector(".chat-window");
    chatWindow.scrollTop = chatWindow.scrollHeight;
});
