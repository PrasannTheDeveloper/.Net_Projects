using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using OllamaAiProject.Models;

namespace OllamaAiProject
{
    public class HomeController : Controller
    {
        private readonly HttpClient _client;
        private readonly string apiUrl = "http://localhost:11434/api/generate";

        // Constructor to inject HttpClient
        public HomeController(HttpClient client)
        {
            _client = client;
        }
        public IActionResult Intro()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Index()
        {
            // Description of the llama3 AI model
            ViewBag.Llama3Description = "Llama3 is a state-of-the-art language model designed to generate human-like text responses. It can assist with various tasks such as answering questions, writing content, or even engaging in casual conversations. It adapts to the context provided and can reflect user preferences based on role and description.";

            return View();
        }

        [HttpPost]
        public IActionResult SetSettings(UserSettingsModel settings)
        {
            if (settings == null)
            {
                return RedirectToAction("Index");
            }

            // Store user and AI settings in session
            HttpContext.Session.SetString("AiRole", settings.AiRole);
            HttpContext.Session.SetString("AiName", settings.AiName);
            HttpContext.Session.SetString("AiDescription", settings.AiDescription);
            HttpContext.Session.SetString("UserName", settings.UserName);
            HttpContext.Session.SetString("UserDescription", settings.UserDescription);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Index(string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                return View();
            }

            // Retrieve stored settings
            string aiRole = HttpContext.Session.GetString("AiRole") ?? "Assistant";
            string aiName = HttpContext.Session.GetString("AiName") ?? "Llama3";
            string aiDescription = HttpContext.Session.GetString("AiDescription") ?? "A helpful AI assistant";
            string userName = HttpContext.Session.GetString("UserName") ?? "User";
            string userDescription = HttpContext.Session.GetString("UserDescription") ?? "A curious learner";

            // Modify prompt to include AI role, name, description & user details
            string finalPrompt = $"You are {aiName}, acting as a {aiRole}. {aiDescription}. The user is {userName}, who is {userDescription}. Respond accordingly.\n\nUser: {userInput}";

            var requestBody = new
            {
                model = "llama3",
                prompt = finalPrompt,
                stream = false
            };

            string jsonRequest = JsonConvert.SerializeObject(requestBody);
            var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

            try
            {
                // API request
                HttpResponseMessage response = await _client.PostAsync(apiUrl, content);
                string responseString = await response.Content.ReadAsStringAsync();

                // AI response
                dynamic jsonResponse = JsonConvert.DeserializeObject(responseString);
                string botReply = jsonResponse.response;

                ViewBag.BotReply = botReply;
            }
            catch (Exception ex)
            {
                ViewBag.BotReply = "Error: " + ex.Message;
            }

            return View();
        }
    }
}