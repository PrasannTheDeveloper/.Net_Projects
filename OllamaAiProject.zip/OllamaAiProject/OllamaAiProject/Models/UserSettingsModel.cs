﻿namespace OllamaAiProject.Models
{
    public class UserSettingsModel
    {
        public string AiRole { get; set; }
        public string AiName { get; set; }
        public string AiDescription { get; set; }
        public string UserName { get; set; }
        public string UserDescription { get; set; }
    }
}